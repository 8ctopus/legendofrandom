#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define DLG_FILE                                101
#define BTN_LOAD                                102
#define CHK_COPY2TEMP                           103
#define BTN_CANCEL                              104
#define BTN_SAVE                                105
